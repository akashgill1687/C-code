// Homework 1-Program using fucntions
#include<stdio.h>
// function declaration
void addValues(int a,int b,int c);
double divideValues(float value1,float value2, float value3);
void callfunc(float a,float b,float c);

int main()
{
    // calling function
    addValues(2,4,6);
    callfunc(36.0,3.0,2.0);
    return 0;
}

// function to add values
void addValues(int a,int b,int c)
{
    //local variable declaration
    int result;
    result=a+b+c;
    printf("%d\n",result);
}

// fucntion to divide values
double divideValues(float value1,float value2, float value3)
{
    //local variable declaration
    double res1;
    double res2;
    //if condition to handle zero values
    if (value2==0||value3==0)
    {
       printf("Attempts to divide by zero\n");
       return 0;
    }
    else
    {
       res1=value1/value2;
       res2=res1/value3;
       return res2;
    }
}
// fucntion to call divideValues function
void callfunc(float a,float b,float c)
{
   double result = divideValues(a,b,c);
   printf("%f\n",result);
}
